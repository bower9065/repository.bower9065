# Kodi Playlist Resumer

- Runs as a service and will periodically update the resume point for an individual file or the entire playlist if items are in Kodi library.
- Will automatically resume a video if Kodi was shutdown while playing it. 
- Can also auto play random video library item if there is nothing to resume.
  - See settings to configure how often the resume point is set, and whether to automatically resume.
  - Adjustable resume point offset
  - Adjustable resume delay