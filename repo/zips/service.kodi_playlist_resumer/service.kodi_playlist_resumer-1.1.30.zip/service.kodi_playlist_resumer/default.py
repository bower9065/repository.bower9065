# -*- coding: utf-8 -*-

from resources.lib import playback_resumer

if __name__ == "__main__":
    playback_resumer.run()
