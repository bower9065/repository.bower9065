from .common import *
import os
import json
import xml.etree.ElementTree as ElementTree
import xbmc

class Store:
    """
    Helper class to read in and store the addon settings, and to provide a centralised store
    """
    save_interval_seconds = 30
    ignore_seconds_at_start = 180
    ignore_percent_at_end = 8
    resume_on_startup = False
    autoplay_random = False
    kodi_event_monitor = None
    player_monitor = None
    just_woke = False
    just_suspend = False
    currently_playing_file_path = ''
    type_of_video = None
    was_trailer = False
    was_audio = False
    library_id = -1
    paused_time = None
    length_of_currently_playing_file = 0
    video_types_in_library = {'episodes': True, 'movies': True, 'musicvideos': True}
    file_to_store_playlist_items = ''
    file_to_store_resume_point = ''
#    file_to_store_playlist_shuffled = ''
    file_to_store_playlist_position = ''
    
    def __init__(self):
        """
        Load in the addon settings and do some basic initialisation stuff
        """
        Store.load_config_from_settings()
        if not os.path.exists(PROFILE):
            os.makedirs(PROFILE)
        Store.file_to_store_playlist_items = os.path.join(PROFILE, "playlist items.txt")
        Store.file_to_store_resume_point = os.path.join(PROFILE, "resume point.txt")
        Store.file_to_store_playlist_position = os.path.join(PROFILE, "playlist position.txt")
        advancedsettings_file = xbmcvfs.translatePath("special://profile/advancedsettings.xml")
        root = None
        try:
            root = ElementTree.parse(advancedsettings_file).getroot()
            log("Found and parsed advancedsettings.xml")
        except (ElementTree.ParseError, IOError):
            log("Could not find/parse advancedsettings.xml, will use defaults")
        if root is not None:
            element = root.find('./video/ignoresecondsatstart')
            if element is not None:
                log("Found advanced setting ignoresecondsatstart")
                Store.ignore_seconds_at_start = int(element.text)
            element = root.find('./video/ignorepercentatend')
            if element is not None:
                log("Found advanced setting ignorepercentatend")
                Store.ignore_percent_at_end = int(element.text)
        log(f"Using ignoresecondsatstart: {Store.ignore_seconds_at_start}, ignorepercentatend: {Store.ignore_percent_at_end}")

    @staticmethod
    def clear_old_play_details():
        """
        As soon as a new file is played, clear out all old references to anything that was being stored as the currently playing file
        :return:
        """
        log("New playback - clearing legacy now playing details")
        Store.library_id = None
        Store.currently_playing_file_path = None
        Store.type_of_video = None
        Store.paused_time = None
        Store.length_of_currently_playing_file = None
        with open(Store.file_to_store_playlist_items, 'w+', encoding='utf-8') as f:
            f.write('[]')
        with open(Store.file_to_store_resume_point, 'w+') as f:
            f.write('')
        with open(Store.file_to_store_playlist_position, 'w+') as f:
            f.write('')            
    @staticmethod
    def load_config_from_settings():
        """
        Load in the addon settings, at start or reload them if they have been changed
        :return:
        """
        log("Loading configuration")
        Store.save_interval_seconds = int(float(ADDON.getSetting("saveintervalsecs")))
        Store.randomitems = int(get_setting("randomitems"))
        Store.resume_on_startup = get_setting_as_bool("resumeonstartup")
        Store.autoplay_random = get_setting_as_bool("autoplayrandom")   
        Store.random_delay = get_setting('random_delay')
        Store.resume_if_stopped = get_setting_as_bool("resumeifstopped")
        Store.resume_delay = get_setting('resume_delay')
        Store.resume_offset = get_setting('resumeoffset')      
        Store.log_configuration()

    @staticmethod
    def log_configuration():
        log(f'Will save a resume point every {Store.save_interval_seconds} seconds')
        log(f'Resume on startup: {Store.resume_on_startup}')
        log(f'Autoplay random video: {Store.autoplay_random}')

    @staticmethod
    def is_excluded(full_path):
        """
        Check exclusion settings for a given file
        :param full_path: the full path of the file to check if is excluded
        :return:
        """
        if not full_path:
            return True
        log(f'Store.isExcluded(): Checking exclusion settings for [{full_path}]')
        if (full_path.find("pvr://") > -1) and getSettingAsBool('ExcludeLiveTV'):
            log('Store.isExcluded(): Video is PVR (Live TV), which is currently set as an excluded source.')
            return True
        if (full_path.find("http://") > -1 or full_path.find("https://") > -1) and get_setting_as_bool('ExcludeHTTP'):
            log("Store.isExcluded(): Video is from an HTTP/S source, which is currently set as an excluded source.")
            return True
        exclude_path = get_setting('exclude_path')
        if exclude_path and get_setting_as_bool('ExcludePathOption'):
            if full_path.find(exclude_path) > -1:
                log(f'Store.isExcluded(): Video is playing from [{exclude_path}], which is set as excluded path 1.')
                return True
        exclude_path2 = get_setting('exclude_path2')
        if exclude_path2 and get_setting_as_bool('ExcludePathOption2'):
            if full_path.find(exclude_path2) > -1:
                log(f'Store.isExcluded(): Video is playing from [{exclude_path2}], which is set as excluded path 2.')
                return True
        exclude_path3 = get_setting('exclude_path3')
        if exclude_path3 and get_setting_as_bool('ExcludePathOption3'):
            if full_path.find(exclude_path3) > -1:
                log(f'Store.isExcluded(): Video is playing from [{exclude_path3}], which is set as excluded path 3.')
                return True
        return False

    @staticmethod
    def update_current_playing_file_path(filepath):
        """
        Persistently tracks the currently playing file (in case of crash, for possible resuming)
        """
        if Store.is_excluded(filepath):
            log("Skipping excluded filepath: " + filepath)
            Store.currently_playing_file_path = None
            return
        query = {
            "jsonrpc": "2.0",
            "method": "Files.GetFileDetails",
            "params": {
                "file": filepath,
                "media": "video",
                "properties": ["playcount", "runtime"]
            },
            "id": "fileDetailsCheck"
        }
        log(f'Executing JSON-RPC: {json.dumps(query)}')
        json_response = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
        log(f'JSON-RPC Files.GetFileDetails response: {json.dumps(json_response)}')
        try:
            Store.type_of_video = json_response['result']['filedetails']['type']
        except KeyError:
            Store.library_id = -1
            log(f"ERROR: Kodi did not return even an 'unknown' file type for: {filepath}")
            Store.type_of_video = None
        if Store.type_of_video in ['episode', 'movie', 'musicvideo']:
            Store.library_id = json_response['result']['filedetails']['id']
        else:
            Store.library_id = None
        log(f'Kodi type: {Store.type_of_video}, library id: {Store.library_id}')
        if Store.type_of_video in ['episode', 'movie', 'musicvideo']:
            playlist_query = {
                "jsonrpc": "2.0",
                "method": "Playlist.GetItems",
                "params": {"playlistid": 1},
                "id": "playlist_items"
            }
            player_query = {
                "jsonrpc": "2.0",
                "method": "Player.GetProperties",
                "params": {
                    "playerid": 1,
                    "properties": ["position"]
                },
                "id": "player_properties"
            }
            player_props = json.loads(xbmc.executeJSONRPC(json.dumps(player_query)))
            playlist_items = json.loads(xbmc.executeJSONRPC(json.dumps(playlist_query)))
            final_position = max(0, player_props['result']['position'])
            with open(Store.file_to_store_playlist_position, 'w', encoding='utf8') as f:
                f.write(str(final_position))
            filtered = []
            for item in playlist_items['result'].get('items', []):
                if item["type"] == "movie":
                    filtered.append({"movieid": item['id']})
                elif item["type"] == "episode":
                    filtered.append({"episodeid": item['id']})
                elif item["type"] == "musicvideo":
                    filtered.append({"musicvideoid": item['id']})
            with open(Store.file_to_store_playlist_items, 'w', encoding='utf8') as f:
                f.write(json.dumps(filtered))
            Store.currently_playing_file_path = filepath
            log(f'Last played library file set to: {filepath}')
        else:
            Store.currently_playing_file_path = filepath
            with open(Store.file_to_store_playlist_items, 'w', encoding='utf8') as f:
                f.write(filepath)
            log(f'Last played file set to: {filepath}')
